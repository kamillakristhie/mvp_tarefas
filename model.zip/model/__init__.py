from model.database import Session, Base, engine
from model.tarefa import Tarefa