from sqlalchemy import Column, Integer, String, Boolean
from model.database import Base

class Tarefa(Base):
    __tablename__ = 'tarefas'

    id = Column(Integer, primary_key=True)
    titulo = Column(String(100), nullable=False, unique=True)
    descricao = Column(String(255))
    concluida = Column(Boolean, default=False)