from pydantic import BaseModel

class TarefaBuscaSchema(BaseModel):
    titulo: str