from pydantic import BaseModel

class TarefaSchema(BaseModel):
    titulo: str
    descricao: str = ""