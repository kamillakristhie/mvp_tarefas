from model.tarefa import Tarefa

def apresenta_tarefa(tarefa: Tarefa):
    return {
        "id": tarefa.id,
        "titulo": tarefa.titulo,
        "descricao": tarefa.descricao,
        "concluida": tarefa.concluida
    }

def apresenta_tarefas(tarefas: list[Tarefa]):
    return [apresenta_tarefa(t) for t in tarefas]