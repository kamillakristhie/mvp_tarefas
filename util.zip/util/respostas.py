from flask import jsonify

def resposta_sucesso(conteudo, status_code):
    return jsonify({"status": "sucesso", "data": conteudo}), status_code

def resposta_erro(status_code, mensagem):
    return jsonify({"status": "erro", "mensagem": mensagem}), status_code